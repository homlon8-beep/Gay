/**
 * Webify Multi-Platform Multi-Account Lead Scraper
 * Discovers businesses & founders worldwide with Territory Partitioning
 * Each WhatsApp number harvests completely DIFFERENT leads so accounts never collide!
 * Continuous query rotation ensures the bot gives fresh, diverse leads all the time.
 */

const fs = require('fs');
const path = require('path');

const APIFY_TOKEN = process.env.APIFY_API_TOKEN;
const LEADS_FILE = path.join(__dirname, 'leads_db.json');
const BACKUP_FILE = path.join(__dirname, 'leads_db.backup.json');
const SENT_HISTORY_FILE = path.join(__dirname, 'sent_history.json');

let cachedDb = null;

/**
 * Permanent Sent History Tracker (Ensures NO recipient is EVER messaged twice across any account)
 */
function loadSentHistory() {
  try {
    if (fs.existsSync(SENT_HISTORY_FILE)) {
      const raw = fs.readFileSync(SENT_HISTORY_FILE, 'utf8');
      const list = JSON.parse(raw);
      if (Array.isArray(list)) return new Set(list);
    }
  } catch (e) {}
  return new Set();
}

function recordSentPhone(phone) {
  if (!phone) return;
  const digits = String(phone).replace(/\D/g, '');
  const history = loadSentHistory();
  history.add(digits);
  try {
    fs.writeFileSync(SENT_HISTORY_FILE, JSON.stringify([...history], null, 2), 'utf8');
  } catch (e) {}
}

function recordBulkSentPhones(phoneList) {
  if (!Array.isArray(phoneList)) return { added: 0, total: 0 };
  const history = loadSentHistory();
  let added = 0;
  for (const p of phoneList) {
    const digits = String(p).replace(/\D/g, '');
    if (digits && digits.length >= 7 && !history.has(digits)) {
      history.add(digits);
      added++;
    }
  }
  if (added > 0) {
    try {
      fs.writeFileSync(SENT_HISTORY_FILE, JSON.stringify([...history], null, 2), 'utf8');
      console.log(`🛡️ [Sent History Shield] Recorded ${added} past numbers in permanent shield ledger. Total shielded: ${history.size}`);
    } catch (e) {
      console.error('Error saving sent history:', e.message);
    }
  }
  return { added, total: history.size };
}

function getTotalShieldedCount() {
  return loadSentHistory().size;
}

function isPhoneAlreadySent(phone) {
  if (!phone) return false;
  const digits = String(phone).replace(/\D/g, '');
  const history = loadSentHistory();
  return history.has(digits);
}

function loadDatabase() {
  if (cachedDb && cachedDb.leads && Array.isArray(cachedDb.leads)) {
    return cachedDb;
  }
  try {
    if (fs.existsSync(LEADS_FILE)) {
      const raw = fs.readFileSync(LEADS_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.leads)) {
        cachedDb = parsed;
        return cachedDb;
      }
    }
  } catch (e) {
    console.warn('⚠️ Main leads_db.json read error, attempting backup restore:', e.message);
  }

  // Fallback to backup file
  try {
    if (fs.existsSync(BACKUP_FILE)) {
      const raw = fs.readFileSync(BACKUP_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.leads)) {
        console.log('✅ Successfully restored leads database from backup!');
        cachedDb = parsed;
        return cachedDb;
      }
    }
  } catch (backupErr) {
    console.error('Backup read failed:', backupErr.message);
  }

  cachedDb = { leads: [], sentCount: 0 };
  return cachedDb;
}

function saveDatabase(db) {
  if (!db || !Array.isArray(db.leads)) return;
  cachedDb = db;
  const tempFile = path.join(__dirname, `leads_db.tmp.${Date.now()}`);
  try {
    const jsonStr = JSON.stringify(db, null, 2);
    fs.writeFileSync(tempFile, jsonStr, 'utf8');
    fs.renameSync(tempFile, LEADS_FILE);
    fs.writeFileSync(BACKUP_FILE, jsonStr, 'utf8');
  } catch (e) {
    console.error('Error saving leads DB:', e.message);
    if (fs.existsSync(tempFile)) {
      try { fs.unlinkSync(tempFile); } catch (err) {}
    }
  }
}

/**
 * Clean & Format International Phone Numbers into Baileys JID
 */
function formatWhatsAppJid(rawNumber) {
  if (!rawNumber) return null;
  let rawStr = String(rawNumber).trim();
  let digits = rawStr.replace(/\D/g, '');

  let country = 'GLOBAL';

  if (rawStr.startsWith('+91') || (digits.startsWith('91') && digits.length === 12)) {
    digits = digits.startsWith('91') ? digits : '91' + digits;
    country = 'India';
  } else if (rawStr.startsWith('+1') || (digits.startsWith('1') && digits.length === 11)) {
    digits = digits.startsWith('1') ? digits : '1' + digits;
    country = 'USA';
  } else if (rawStr.startsWith('+44') || (digits.startsWith('44') && (digits.length === 12 || digits.length === 11))) {
    digits = digits.startsWith('44') ? digits : '44' + digits;
    country = 'UK';
  } else if (digits.startsWith('07') && digits.length === 11) {
    digits = '44' + digits.slice(1);
    country = 'UK';
  } else if (rawStr.startsWith('+61') || (digits.startsWith('61') && digits.length === 11)) {
    digits = digits.startsWith('61') ? digits : '61' + digits;
    country = 'Australia';
  } else if (digits.length === 10) {
    digits = '1' + digits;
    country = 'USA';
  } else if (digits.startsWith('0') && digits.length === 11) {
    digits = '91' + digits.slice(1);
    country = 'India';
  } else if (digits.startsWith('04') && digits.length === 10) {
    digits = '61' + digits.slice(1);
    country = 'Australia';
  } else if (digits.length >= 10 && digits.length <= 15) {
    country = 'GLOBAL';
  } else {
    return null;
  }

  return {
    cleanNumber: digits,
    jid: `${digits}@s.whatsapp.net`,
    country: country
  };
}

/**
 * Multi-Account Territory & Niche Partitioning
 * Guarantees that Account 1, Account 2, Account 3 harvest completely different leads
 */
const TERRITORIES = {
  account_1: {
    name: 'East & Central US - Structural & High-Ticket Trades',
    cities: [
      'newyork', 'chicago', 'houston', 'atlanta', 'miami', 
      'boston', 'philadelphia', 'charlotte', 'raleigh', 'tampa', 
      'detroit', 'minneapolis', 'columbus', 'pittsburgh', 'indianapolis', 'cleveland'
    ],
    niches: [
      'roofing', 'hvac', 'remodeling', 'general contractor', 'flooring', 
      'plumber', 'commercial cleaning', 'masonry', 'siding', 'kitchen remodel', 
      'bathroom remodel', 'insulation', 'concrete contractor', 'water damage'
    ]
  },
  account_2: {
    name: 'West & South US - Essential Home & Fast Services',
    cities: [
      'losangeles', 'dallas', 'austin', 'phoenix', 'sandiego', 
      'denver', 'lasvegas', 'seattle', 'sanantonio', 'orlando', 
      'portland', 'sacramento', 'sanfrancisco', 'saltlakecity', 'tucson', 'fortworth'
    ],
    niches: [
      'electrician', 'landscaping', 'pressure washing', 'pest control', 'moving company', 
      'handyman', 'painter', 'tree service', 'epoxy flooring', 'carpet cleaning', 
      'fence installation', 'garage door repair', 'window cleaning', 'locksmith'
    ]
  },
  account_3: {
    name: 'Global & Digital Metros - Agencies, Clinics & Founders',
    cities: [
      'london', 'toronto', 'vancouver', 'sydney', 'melbourne', 
      'manchester', 'birmingham', 'leeds', 'calgary', 'brisbane'
    ],
    niches: [
      'web design', 'marketing agency', 'medspa', 'chiropractor', 'gym', 
      'real estate', 'solar installation', 'auto detailing', 'wellness clinic', 'accounting'
    ]
  }
};

function getTerritoryForAccount(accountId) {
  if (TERRITORIES[accountId]) return TERRITORIES[accountId];
  // Dynamic fallback for account_4, account_5...
  const allCities = [...TERRITORIES.account_1.cities, ...TERRITORIES.account_2.cities, ...TERRITORIES.account_3.cities];
  const allNiches = [...TERRITORIES.account_1.niches, ...TERRITORIES.account_2.niches, ...TERRITORIES.account_3.niches];
  return {
    name: `Territory for ${accountId}`,
    cities: allCities.sort(() => 0.5 - Math.random()),
    niches: allNiches.sort(() => 0.5 - Math.random())
  };
}

const TOLL_FREE_PREFIXES = new Set(['800', '888', '877', '866', '855', '844', '833']);
function isTollFree(cleanNumber) {
  const digits = String(cleanNumber).replace(/\D/g, '');
  const areaCode = digits.startsWith('1') ? digits.slice(1, 4) : digits.slice(0, 3);
  return TOLL_FREE_PREFIXES.has(areaCode);
}

/**
 * Add unique leads to database, tagging with assigned account
 */
function addLeadsToQueue(newLeads = [], defaultAccount = null) {
  const db = loadDatabase();
  const existingPhones = new Set(db.leads.map(l => l.phone));
  let added = 0;

  for (const item of newLeads) {
    const formatted = formatWhatsAppJid(item.phone || item.number);
    if (!formatted) continue;

    // Never queue numbers already messaged in past sessions
    if (isPhoneAlreadySent(formatted.cleanNumber)) {
      continue;
    }

    if (!existingPhones.has(formatted.cleanNumber)) {
      const assigned = item.assignedAccount || defaultAccount || null;
      const newLeadObj = {
        phone: formatted.cleanNumber,
        jid: formatted.jid,
        country: formatted.country || item.country || 'USA',
        name: item.name || '',
        niche: item.niche || 'Business Owner',
        trade: item.trade || item.niche || 'local service',
        city: item.city || 'your area',
        source: item.source || 'multi_account_scraper',
        query: item.query || '',
        assignedAccount: assigned,
        discoveredAt: new Date().toISOString(),
        status: 'queued',
        lastSentAt: null
      };

      db.leads.push(newLeadObj);
      existingPhones.add(formatted.cleanNumber);
      added++;
    }
  }

  saveDatabase(db);
  console.log(`✅ [Webify Leads DB] Added ${added} new unique leads${defaultAccount ? ` for ${defaultAccount}` : ''}. Total in DB: ${db.leads.length}`);
  return { added, total: db.leads.length };
}

/**
 * Get next lead for a specific account (Ensures NO two accounts ever pull the same lead)
 */
function getQueuedLeadForAccount(accountId) {
  const db = loadDatabase();

  // 1. First look for a lead explicitly assigned to this account
  let lead = db.leads.find(l => l.status === 'queued' && l.assignedAccount === accountId && !isPhoneAlreadySent(l.phone));

  // 2. If none, look for an unassigned queued lead and claim it for this account
  if (!lead) {
    lead = db.leads.find(l => l.status === 'queued' && !l.assignedAccount && !isPhoneAlreadySent(l.phone));
    if (lead) {
      lead.assignedAccount = accountId;
      saveDatabase(db);
    }
  }

  return lead || null;
}

/**
 * Get queued leads count for a specific account or total
 */
function getQueuedLeadsCount(accountId = null) {
  const db = loadDatabase();
  if (accountId) {
    return db.leads.filter(l => l.status === 'queued' && (l.assignedAccount === accountId || !l.assignedAccount)).length;
  }
  return db.leads.filter(l => l.status === 'queued').length;
}

function getQueuedLeads(limit = 10) {
  const db = loadDatabase();
  return db.leads.filter(l => l.status === 'queued').slice(0, limit);
}

/**
 * Update status of a lead
 */
function updateLeadStatus(phone, status, error = null) {
  const db = loadDatabase();
  const cleanDigits = String(phone).replace(/\D/g, '');
  const lead = db.leads.find(l => l.phone === cleanDigits || l.phone === phone || (l.jid && l.jid.includes(cleanDigits)));
  if (lead) {
    lead.status = status;
    if (status === 'sent') {
      lead.lastSentAt = new Date().toISOString();
      db.sentCount = (db.sentCount || 0) + 1;
      recordSentPhone(cleanDigits);
    }
    if (error) lead.lastError = error;
    saveDatabase(db);
  }
}

/**
 * Free Multi-Account Web Scraper
 * Uses dynamic query variation, city cycling, and search query expansion
 * to guarantee that the bot yields DIFFERENT leads all the time!
 */
async function triggerFreeWebScraper(options = {}) {
  const targetAccount = options.targetAccount || 'account_1';
  const minLeads = options.targetCount || 30;
  const territory = getTerritoryForAccount(targetAccount);

  console.log(`⚡ [Multi-Scraper - ${targetAccount}] Harvesting fresh leads in: ${territory.name}...`);

  const extracted = [];
  const seenPhonesInBatch = new Set();
  const phoneRegex = /(?:\+?1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})\b/g;

  // Query variations to fetch different leads every time (not just the same top 10)
  const queryModifiers = ['', 'commercial', 'residential', 'emergency', 'licensed', 'affordable', 'services', 'pro'];

  // Shuffle cities and niches for maximum diversity
  const cityList = options.targetCity ? [options.targetCity] : [...territory.cities].sort(() => 0.5 - Math.random());
  const nicheList = options.targetNiche ? [options.targetNiche] : [...territory.niches].sort(() => 0.5 - Math.random());

  for (const city of cityList) {
    if (extracted.length >= minLeads) break;

    for (const niche of nicheList) {
      if (extracted.length >= minLeads) break;

      const modifier = queryModifiers[Math.floor(Math.random() * queryModifiers.length)];
      const fullQuery = modifier ? `${modifier} ${niche}` : niche;
      const searchUrl = `https://${city}.craigslist.org/search/bbb?query=${encodeURIComponent(fullQuery)}`;

      try {
        const res = await fetch(searchUrl, {
          signal: AbortSignal.timeout(6000),
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
          }
        });

        if (!res.ok) continue;
        const html = await res.text();
        const results = [...html.matchAll(/<li class="cl-static-search-result"[^>]*>(.*?)<\/li>/gs)].map(m => m[1]);
        if (results.length === 0) continue;

        const candidatePostsToFetch = [];

        for (const r of results) {
          if (extracted.length >= minLeads) break;

          const titleMatch = r.match(/<div class="title">(.*?)<\/div>/);
          const rawTitle = titleMatch ? titleMatch[1].replace(/<[^>]+>/g, '').trim() : `${niche} specialist`;
          const matches = [...r.matchAll(phoneRegex)].map(m => m[0]);

          let foundInCard = false;
          for (const phone of matches) {
            const cleanDigits = phone.replace(/\D/g, '');
            if ((cleanDigits.length === 10 || (cleanDigits.length === 11 && cleanDigits.startsWith('1'))) && !isTollFree(cleanDigits)) {
              if (!seenPhonesInBatch.has(cleanDigits) && !isPhoneAlreadySent(cleanDigits)) {
                seenPhonesInBatch.add(cleanDigits);
                extracted.push({
                  phone: phone,
                  name: rawTitle.replace(/[^\w\s-]/g, '').slice(0, 35).trim() || 'Business Owner',
                  niche: `${niche.charAt(0).toUpperCase() + niche.slice(1)} (${city.toUpperCase()})`,
                  trade: niche,
                  city: city,
                  country: 'USA',
                  assignedAccount: targetAccount,
                  source: `free_scraper_${targetAccount}`,
                  query: `${city} - ${fullQuery}`
                });
                foundInCard = true;
                break;
              }
            }
          }

          if (!foundInCard && candidatePostsToFetch.length < 8) {
            const linkMatch = r.match(/<a href="([^"]+)"/);
            if (linkMatch) {
              candidatePostsToFetch.push({ postUrl: linkMatch[1], rawTitle });
            }
          }
        }

        // Concurrent fetch for posts where phone was in description
        if (extracted.length < minLeads && candidatePostsToFetch.length > 0) {
          const fetchPromises = candidatePostsToFetch.map(async ({ postUrl, rawTitle }) => {
            try {
              const postRes = await fetch(postUrl, {
                signal: AbortSignal.timeout(5000),
                headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
              });
              if (!postRes.ok) return null;
              const postHtml = await postRes.text();
              const bodyMatch = postHtml.match(/<section id="postingbody"[^>]*>(.*?)<\/section>/s);
              if (!bodyMatch) return null;
              const bodyClean = bodyMatch[1].replace(/<[^>]+>/g, ' ');
              const foundPhones = [...bodyClean.matchAll(phoneRegex)].map(m => m[0]);
              for (const phone of foundPhones) {
                const cleanDigits = phone.replace(/\D/g, '');
                if ((cleanDigits.length === 10 || (cleanDigits.length === 11 && cleanDigits.startsWith('1'))) && !isTollFree(cleanDigits)) {
                  return { phone, rawTitle, cleanDigits };
                }
              }
            } catch (e) {
              return null;
            }
            return null;
          });

          const postResults = await Promise.allSettled(fetchPromises);
          for (const pr of postResults) {
            if (pr.status === 'fulfilled' && pr.value) {
              const { phone, rawTitle, cleanDigits } = pr.value;
              if (!seenPhonesInBatch.has(cleanDigits) && !isPhoneAlreadySent(cleanDigits)) {
                seenPhonesInBatch.add(cleanDigits);
                extracted.push({
                  phone: phone,
                  name: rawTitle.replace(/[^\w\s-]/g, '').slice(0, 35).trim() || 'Business Owner',
                  niche: `${niche.charAt(0).toUpperCase() + niche.slice(1)} (${city.toUpperCase()})`,
                  trade: niche,
                  city: city,
                  country: 'USA',
                  assignedAccount: targetAccount,
                  source: `free_scraper_${targetAccount}`,
                  query: `${city} - ${fullQuery}`
                });
              }
            }
          }
        }
      } catch (err) {}
    }
  }

  console.log(`🎯 [Multi-Scraper - ${targetAccount}] Harvested ${extracted.length} verified leads for ${territory.name}.`);
  return addLeadsToQueue(extracted, targetAccount);
}

/**
 * Apify Lead Discovery (Fallback)
 */
async function triggerApifyLeadDiscovery(targetAccount = 'account_1') {
  if (!APIFY_TOKEN) return [];
  console.log(`🔍 [Apify Multi-Account] Running lead discovery for ${targetAccount}...`);

  const territory = getTerritoryForAccount(targetAccount);
  const sampleCity = territory.cities[Math.floor(Math.random() * territory.cities.length)];
  const sampleNiche = territory.niches[Math.floor(Math.random() * territory.niches.length)];

  const searchQueries = [
    `site:facebook.com ("call or text" OR "DM to order") ("${sampleNiche}" OR "contractor") ("${sampleCity}" OR "Texas" OR "Florida" OR "California") -site:linktr.ee`,
    `site:instagram.com ("call or text" OR "DM for quote") ("${sampleNiche}") ("no website" OR "website coming soon")`,
    `site:reddit.com/r/smallbusiness ("need a website for my ${sampleNiche}" OR "need more leads")`,
    `("${sampleNiche}") ("${sampleCity}") ("call or text" OR "text us at") ("+1" OR "phone:") -site:yelp.com`
  ];

  try {
    const runResponse = await fetch(`https://api.apify.com/v2/acts/apify~google-search-scraper/run-sync-get-dataset-items?token=${APIFY_TOKEN}&memory=512`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        queries: searchQueries.join('\n'),
        maxPagesPerQuery: 1,
        resultsPerPage: 25,
        mobileResults: true,
        languageCode: 'en'
      })
    });

    if (!runResponse.ok) return [];

    const items = await runResponse.json();
    const extracted = [];
    const phoneRegex = /(?:\+?1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})\b|(?:\+?44[-.\s]?|0)7\d{3}[-.\s]?\d{6}\b|(?:\+?91|0)?[6-9]\d{9}\b|\+?[1-9]\d{9,14}\b/g;

    for (const item of items) {
      const textToSearch = `${item.title || ''} ${item.description || ''} ${item.snippet || ''}`;
      const matches = textToSearch.match(phoneRegex);
      if (matches) {
        for (const phone of matches) {
          extracted.push({
            phone: phone,
            name: (item.title || '').split(/[-|–]/)[0].trim().slice(0, 30),
            niche: (item.searchQuery || sampleNiche).slice(0, 25),
            trade: sampleNiche,
            city: sampleCity,
            assignedAccount: targetAccount,
            source: `apify_${targetAccount}`,
            query: item.searchQuery || ''
          });
        }
      }
    }

    return addLeadsToQueue(extracted, targetAccount);
  } catch (err) {
    console.error('❌ Apify Run Failed:', err.message);
    return [];
  }
}

let is247ScraperRunning = false;
let isScraperPaused = false;
let scraperStats = {
  status: 'Autonomous Multi-Territory Harvest Active',
  cyclesCompleted: 0,
  leadsHarvestedSession: 0,
  lastScrapedAccount: 'account_1',
  lastScrapedCity: 'Dallas',
  lastScrapedNiche: 'roofing',
  lastRunTime: null
};

function pauseScraper() {
  isScraperPaused = true;
  scraperStats.status = 'Scraper Paused by User';
  console.log('⏸️ [Free Scraper Engine] Paused by user.');
}

function resumeScraper() {
  isScraperPaused = false;
  scraperStats.status = 'Resuming Multi-Territory Harvest...';
  console.log('▶️ [Free Scraper Engine] Resumed by user.');
}

function getScraperStats() {
  const db = loadDatabase();
  return {
    ...scraperStats,
    isPaused: isScraperPaused,
    totalInDb: db.leads.length,
    queuedCount: db.leads.filter(l => l.status === 'queued').length,
    sentCount: db.leads.filter(l => l.status === 'sent').length
  };
}

/**
 * Continuous 24/7 autonomous scraper that dynamically feeds ALL accounts with diverse leads
 */
async function start247ContinuousScraper() {
  if (is247ScraperRunning) return;
  is247ScraperRunning = true;
  console.log('🌍 [24/7 Multi-Territory Scraper Engine] Running continuous harvest across all accounts!');

  const accountKeys = ['account_1', 'account_2', 'account_3'];
  let currentAccIndex = 0;

  while (is247ScraperRunning) {
    if (isScraperPaused) {
      await new Promise(r => setTimeout(r, 4000));
      continue;
    }

    try {
      const activeAccount = accountKeys[currentAccIndex % accountKeys.length];
      currentAccIndex++;

      const queuedForAcc = getQueuedLeadsCount(activeAccount);

      // If this account has plenty of leads, skip to next account or rest
      if (queuedForAcc >= 50) {
        await new Promise(r => setTimeout(r, 6000));
        continue;
      }

      const territory = getTerritoryForAccount(activeAccount);
      const city = territory.cities[Math.floor(Math.random() * territory.cities.length)];
      const niche = territory.niches[Math.floor(Math.random() * territory.niches.length)];

      scraperStats.lastScrapedAccount = activeAccount;
      scraperStats.lastScrapedCity = city;
      scraperStats.lastScrapedNiche = niche;
      scraperStats.lastRunTime = new Date().toISOString();
      scraperStats.status = `Harvesting for ${activeAccount} in ${city.toUpperCase()} (${niche})...`;

      const result = await triggerFreeWebScraper({
        targetAccount: activeAccount,
        targetCount: 30,
        targetCity: city,
        targetNiche: niche
      });

      scraperStats.cyclesCompleted++;
      scraperStats.leadsHarvestedSession += (result?.added || 0);

      // Brief sleep between sweeps to be gentle on CPU
      await new Promise(r => setTimeout(r, 12000));
    } catch (err) {
      console.error('❌ [Continuous Scraper Exception]:', err.message);
      await new Promise(r => setTimeout(r, 15000));
    }
  }
}

module.exports = {
  loadDatabase,
  saveDatabase,
  addLeadsToQueue,
  getQueuedLeads,
  getQueuedLeadForAccount,
  getQueuedLeadsCount,
  updateLeadStatus,
  triggerFreeWebScraper,
  triggerApifyLeadDiscovery,
  start247ContinuousScraper,
  pauseScraper,
  resumeScraper,
  isPhoneAlreadySent,
  recordSentPhone,
  recordBulkSentPhones,
  getTotalShieldedCount,
  getScraperStats,
  formatWhatsAppJid,
  getTerritoryForAccount,
  TERRITORIES
};
