/**
 * Webify Multi-Account WhatsApp Baileys Client
 * Supports multiple simultaneous WhatsApp numbers / accounts
 * Each account runs independently with its own auth session, QR code, chat sync,
 * slow real-human replying, and anti-ban telemetry.
 */

const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');
const pino = require('pino');
const QRCode = require('qrcode');
const path = require('path');
const fs = require('fs');
const ai = require('./ai');
const scraper = require('./scraper');

const AUTH_BASE_DIR = path.join(__dirname, 'auth_info_baileys');

// Ensure base auth directory exists
if (!fs.existsSync(AUTH_BASE_DIR)) {
  fs.mkdirSync(AUTH_BASE_DIR, { recursive: true });
}

// Automatic Migration: If an existing single-account session was in root auth_info_baileys, migrate it to account_1
if (fs.existsSync(path.join(AUTH_BASE_DIR, 'creds.json'))) {
  const acc1Dir = path.join(AUTH_BASE_DIR, 'account_1');
  if (!fs.existsSync(acc1Dir)) {
    fs.mkdirSync(acc1Dir, { recursive: true });
    const items = fs.readdirSync(AUTH_BASE_DIR);
    for (const item of items) {
      const fullPath = path.join(AUTH_BASE_DIR, item);
      if (fs.statSync(fullPath).isFile()) {
        try {
          fs.renameSync(fullPath, path.join(acc1Dir, item));
        } catch (e) {}
      }
    }
    console.log('🔄 [WhatsApp Multi-Account] Automatically migrated existing single-account session to Account 1.');
  }
}

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Multi-Account Registry: accountId -> AccountSession
const accounts = new Map();

// Global Shield Set for all past chats across ALL connected accounts
const globalChatsSet = new Set();

function registerExistingChat(jid) {
  if (!jid) return;
  const cleanDigits = String(jid).split('@')[0].replace(/\D/g, '');
  if (cleanDigits && cleanDigits.length >= 7) {
    globalChatsSet.add(cleanDigits);
    scraper.recordSentPhone(cleanDigits);
  }
}

function hasAnyExistingChat(phoneOrJid) {
  if (!phoneOrJid) return false;
  const cleanDigits = String(phoneOrJid).replace(/\D/g, '');
  return globalChatsSet.has(cleanDigits) || scraper.isPhoneAlreadySent(cleanDigits);
}

// Helper to extract text from all nested WhatsApp message types
function extractMessageText(msg) {
  if (!msg || !msg.message) return '';
  let m = msg.message;
  if (m.ephemeralMessage?.message) m = m.ephemeralMessage.message;
  if (m.viewOnceMessage?.message) m = m.viewOnceMessage.message;
  if (m.viewOnceMessageV2?.message) m = m.viewOnceMessageV2.message;
  if (m.documentWithCaptionMessage?.message) m = m.documentWithCaptionMessage.message;

  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    m.buttonsResponseMessage?.selectedDisplayText ||
    m.buttonsResponseMessage?.selectedButtonId ||
    m.templateButtonReplyMessage?.selectedId ||
    m.templateButtonReplyMessage?.selectedDisplayText ||
    m.listResponseMessage?.title ||
    m.listResponseMessage?.singleSelectReply?.selectedRowId ||
    ''
  );
}

/**
 * Create or get an account session
 */
function createAccount(id, label = null) {
  if (accounts.has(id)) return accounts.get(id);

  const defaultLabels = {
    account_1: 'Number 1 (US East & Central Focus)',
    account_2: 'Number 2 (US West & South Focus)',
    account_3: 'Number 3 (Global & Digital Focus)',
    account_4: 'Number 4 (Expansion Line)',
    account_5: 'Number 5 (Expansion Line)'
  };

  const session = {
    id,
    label: label || defaultLabels[id] || `Number ${id.replace(/\D/g, '') || id}`,
    authDir: path.join(AUTH_BASE_DIR, id),
    sock: null,
    isConnected: false,
    phone: null,
    qrDataUrl: null,
    isReconnecting: false,
    pendingReplies: new Map(),
    conversationHistories: new Map(),
    onReadyCallbacks: []
  };

  if (!fs.existsSync(session.authDir)) {
    fs.mkdirSync(session.authDir, { recursive: true });
  }

  accounts.set(id, session);
  return session;
}

/**
 * Initialize a single account socket
 */
async function initAccountSocket(account) {
  if (account.sock) {
    try {
      account.sock.ev.removeAllListeners();
      account.sock.end();
    } catch (e) {}
    account.sock = null;
  }

  const { state, saveCreds } = await useMultiFileAuthState(account.authDir);

  const sock = makeWASocket({
    auth: state,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    browser: [`Webify Bot (${account.id})`, 'Chrome', '124.0.0']
  });

  account.sock = sock;

  // Save auth state changes
  sock.ev.on('creds.update', saveCreds);

  // Connection update event
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      try {
        account.qrDataUrl = await QRCode.toDataURL(qr);
        console.log(`📲 [WhatsApp QR - ${account.label}] New QR Code generated! Open /qr?acc=${account.id} to scan.`);
      } catch (err) {
        console.error(`Failed to generate QR data URL for ${account.id}:`, err.message);
      }
    }

    if (connection === 'close') {
      account.isConnected = false;
      account.qrDataUrl = null;
      const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log(`⚠️ [WhatsApp - ${account.label}] Socket closed (${lastDisconnect?.error?.message || 'timeout'}). Reconnecting: ${shouldReconnect}`);

      if (shouldReconnect && !account.isReconnecting) {
        account.isReconnecting = true;
        setTimeout(() => {
          account.isReconnecting = false;
          initAccountSocket(account);
        }, 5000);
      } else if (!shouldReconnect) {
        console.log(`❌ [WhatsApp - ${account.label}] Session logged out. Open /qr?acc=${account.id} to rescan.`);
      }
    } else if (connection === 'open') {
      account.isConnected = true;
      account.qrDataUrl = null;
      account.isReconnecting = false;
      account.phone = sock.user?.id ? sock.user.id.split(':')[0] : 'Connected';
      console.log(`\n🎉 [WhatsApp - ${account.label}] Connected successfully as +${account.phone}! Line is ACTIVE.\n`);

      for (const cb of account.onReadyCallbacks) {
        try { cb(account); } catch (e) {}
      }
    }
  });

  // History sync across accounts
  sock.ev.on('messaging-history.set', ({ chats }) => {
    if (Array.isArray(chats)) {
      console.log(`📥 [History Sync - ${account.label}] Shielding ${chats.length} existing contacts...`);
      for (const c of chats) registerExistingChat(c.id);
    }
  });

  sock.ev.on('chats.set', ({ chats }) => {
    if (Array.isArray(chats)) {
      for (const c of chats) registerExistingChat(c.id);
    }
  });

  sock.ev.on('chats.upsert', (chats) => {
    if (Array.isArray(chats)) {
      for (const c of chats) registerExistingChat(c.id);
    }
  });

  // Slow Real-Human AI Replying for inbound messages on this number
  sock.ev.on('messages.upsert', async (m) => {
    try {
      if (!m.messages || !Array.isArray(m.messages)) return;

      for (const msg of m.messages) {
        if (!msg || !msg.message) continue;

        const senderJid = msg.key.remoteJid;
        if (!senderJid) continue;

        const cleanPhone = senderJid.replace(/@.*$/, '').replace(/\D/g, '');

        // If manual reply sent from phone, cancel pending AI reply
        if (msg.key.fromMe) {
          if (account.pendingReplies.has(cleanPhone)) {
            clearTimeout(account.pendingReplies.get(cleanPhone).timeout);
            account.pendingReplies.delete(cleanPhone);
            console.log(`✋ [Manual Override - ${account.label}] You messaged ${cleanPhone} from your phone. Canceled pending AI reply.`);
          }
          continue;
        }

        // Ignore groups, broadcasts, stories
        if (senderJid.endsWith('@g.us') || senderJid.endsWith('@broadcast') || senderJid === 'status@broadcast') {
          continue;
        }

        const incomingText = extractMessageText(msg).trim();
        if (!incomingText) continue;

        console.log(`\n📩 [Inbound Lead on ${account.label} from ${cleanPhone}]: "${incomingText}"`);

        // Check STOP / opt out
        const lower = incomingText.toLowerCase();
        if (lower === 'stop' || lower === 'unsubscribe' || lower === 'remove' || lower.includes('stop')) {
          if (account.pendingReplies.has(cleanPhone)) {
            clearTimeout(account.pendingReplies.get(cleanPhone).timeout);
            account.pendingReplies.delete(cleanPhone);
          }
          console.log(`🛑 [Opt-Out Received on ${account.label} from ${cleanPhone}]: Blacklisted permanently.`);
          try {
            scraper.updateLeadStatus(cleanPhone, 'opted_out');
            scraper.recordSentPhone(cleanPhone);
            await sock.sendMessage(senderJid, { text: 'You have been opted out and will receive no further messages. Thank you!' });
          } catch (e) {}
          continue;
        }

        // Mark as replied & shield
        try {
          scraper.updateLeadStatus(cleanPhone, 'replied');
          scraper.recordSentPhone(cleanPhone);
        } catch (e) {}

        // Slow Real-Human Burst Debounce
        let pending = account.pendingReplies.get(cleanPhone);
        if (pending) {
          clearTimeout(pending.timeout);
          pending.messages.push(incomingText);
          pending.lastMsgKey = msg.key;
        } else {
          pending = {
            senderJid,
            cleanPhone,
            messages: [incomingText],
            lastMsgKey: msg.key,
            timeout: null
          };
        }

        const debounceDelayMs = 18000 + Math.floor(Math.random() * 10000);
        console.log(`⏳ [Slow Human AI - ${account.label}] Buffered reply for ${cleanPhone}. Waiting ${(debounceDelayMs / 1000).toFixed(0)}s debounce before reading & typing...`);

        pending.timeout = setTimeout(async () => {
          account.pendingReplies.delete(cleanPhone);
          await processSlowHumanReply(account, pending);
        }, debounceDelayMs);

        account.pendingReplies.set(cleanPhone, pending);
      }
    } catch (msgErr) {
      console.error(`❌ [Error handling incoming messages on ${account.id}]:`, msgErr.message);
    }
  });

  return sock;
}

/**
 * Process Slow Real-Human AI Reply for an account
 */
async function processSlowHumanReply(account, pending) {
  const { senderJid, cleanPhone, messages, lastMsgKey } = pending;
  if (!account.sock || !account.isConnected) return;

  try {
    const combinedIncomingText = messages.join('\n');
    console.log(`\n🤖 [Slow Human AI - ${account.label} Responding to ${cleanPhone}]: "${combinedIncomingText.replace(/\n/g, ' ')}"`);

    // 1. Mark as read (blue ticks)
    try {
      if (lastMsgKey) await account.sock.readMessages([lastMsgKey]);
    } catch (e) {}

    // 2. Slow human reading & thinking pause (12s to 24s)
    const readDelayMs = 12000 + Math.floor(Math.random() * 12000);
    console.log(`👀 [Human Reading - ${account.label}] Chat opened. Reading for ${(readDelayMs / 1000).toFixed(0)}s...`);
    await sleep(readDelayMs);

    const history = account.conversationHistories.get(cleanPhone) || [];

    // 3. Generate AI response via Groq
    let replyText = await ai.handleIncomingMessage(cleanPhone, combinedIncomingText, history);
    if (!replyText || !replyText.trim()) return;
    replyText = replyText.trim();

    // 4. Realistic typing presence (7s - 18s)
    const typingDurationMs = Math.min(
      18000,
      Math.max(7000, replyText.length * 48 + Math.floor(Math.random() * 3000))
    );

    console.log(`✍️ [Human Typing - ${account.label}] Sending 'composing' presence to ${cleanPhone} for ${(typingDurationMs / 1000).toFixed(1)}s...`);
    try {
      await account.sock.sendPresenceUpdate('composing', senderJid);
    } catch (e) {}

    await sleep(typingDurationMs);

    // 5. Hesitation pause
    try {
      await account.sock.sendPresenceUpdate('paused', senderJid);
    } catch (e) {}
    const pauseBeforeSendMs = 1500 + Math.floor(Math.random() * 2000);
    await sleep(pauseBeforeSendMs);

    // 6. Send message
    await account.sock.sendMessage(senderJid, { text: replyText });
    console.log(`✅ [Slow Human AI - ${account.label}] Reply Sent to ${cleanPhone}:\n"${replyText}"\n`);

    // 7. Update conversation history
    history.push({ role: 'user', content: combinedIncomingText });
    history.push({ role: 'assistant', content: replyText });
    if (history.length > 8) history.splice(0, history.length - 8);
    account.conversationHistories.set(cleanPhone, history);

  } catch (err) {
    console.error(`❌ [Error in processSlowHumanReply on ${account.id} for ${cleanPhone}]:`, err.message);
  }
}

/**
 * Initialize all accounts (Default: account_1 and account_2)
 */
async function initWhatsApp(onReadyCallback) {
  // Ensure default account slots exist
  createAccount('account_1');
  createAccount('account_2');

  // Also check if any other subfolders exist in auth_info_baileys (e.g. account_3)
  try {
    const dirs = fs.readdirSync(AUTH_BASE_DIR);
    for (const d of dirs) {
      if (d.startsWith('account_') && fs.statSync(path.join(AUTH_BASE_DIR, d)).isDirectory()) {
        createAccount(d);
      }
    }
  } catch (e) {}

  console.log(`🚀 [WhatsApp Multi-Account] Initializing ${accounts.size} WhatsApp account slots...`);

  const promises = [];
  for (const account of accounts.values()) {
    if (onReadyCallback) {
      account.onReadyCallbacks.push(onReadyCallback);
    }
    promises.push(initAccountSocket(account));
  }

  await Promise.all(promises);
}

/**
 * Send text message from a specific account
 */
async function sendTextMessage(accountId, jid, text) {
  const account = accounts.get(accountId) || accounts.values().next().value;
  if (!account || !account.sock || !account.isConnected) {
    console.warn(`Cannot send message: Account ${accountId} is not connected`);
    return false;
  }

  try {
    await account.sock.sendPresenceUpdate('available');
    await sleep(1200 + Math.random() * 1000);

    // Realistic human typing presence (4.5 to 8.5s)
    await account.sock.sendPresenceUpdate('composing', jid);
    const typingDelay = Math.floor(4500 + Math.random() * 4000);
    await sleep(typingDelay);

    await account.sock.sendMessage(jid, { text: text });
    await account.sock.sendPresenceUpdate('paused', jid);
    return true;
  } catch (err) {
    console.error(`Error sending message via ${accountId} to ${jid}:`, err.message);
    return false;
  }
}

/**
 * Check if number exists on WhatsApp (using a specific account or any connected account)
 */
async function checkNumberOnWhatsApp(accountId, phoneOrJid) {
  let account = accounts.get(accountId);
  if (!account || !account.sock || !account.isConnected) {
    // Fall back to any connected account
    for (const acc of accounts.values()) {
      if (acc.sock && acc.isConnected) {
        account = acc;
        break;
      }
    }
  }

  if (!account || !account.sock || !account.isConnected) {
    return { exists: false, jid: null };
  }

  try {
    const cleanDigits = String(phoneOrJid).replace(/\D/g, '');
    const results = await account.sock.onWhatsApp(cleanDigits);
    if (results && Array.isArray(results) && results.length > 0 && results[0]?.exists) {
      return { exists: true, jid: results[0].jid || `${cleanDigits}@s.whatsapp.net` };
    }
    return { exists: false, jid: null };
  } catch (err) {
    console.warn(`⚠️ [WhatsApp Verify Warning on ${account.id} for ${phoneOrJid}]:`, err.message);
    return { exists: false, jid: null };
  }
}

/**
 * Get account by ID
 */
function getAccount(id) {
  return accounts.get(id) || null;
}

/**
 * Get all accounts summary for UI and queue
 */
function getAllAccounts() {
  const list = [];
  for (const acc of accounts.values()) {
    list.push({
      id: acc.id,
      label: acc.label,
      isConnected: acc.isConnected,
      phone: acc.phone,
      qrDataUrl: acc.qrDataUrl,
      isReconnecting: acc.isReconnecting
    });
  }
  return list;
}

/**
 * Dynamically register and boot a new account slot
 */
async function addNewAccount(customLabel = null) {
  let nextIndex = 1;
  while (accounts.has(`account_${nextIndex}`)) {
    nextIndex++;
  }
  const newId = `account_${nextIndex}`;
  const account = createAccount(newId, customLabel || `Number ${nextIndex}`);
  await initAccountSocket(account);
  console.log(`➕ [WhatsApp Multi-Account] Registered and initialized new account slot: ${newId}`);
  return account;
}

// Backwards compatibility helpers
function isConnected() {
  for (const acc of accounts.values()) {
    if (acc.isConnected) return true;
  }
  return false;
}

function getConnectedNumber() {
  const connectedPhones = [];
  for (const acc of accounts.values()) {
    if (acc.isConnected && acc.phone) connectedPhones.push(acc.phone);
  }
  return connectedPhones.length > 0 ? connectedPhones.join(', +') : null;
}

function getQrCodeDataUrl(accountId = 'account_1') {
  const acc = accounts.get(accountId) || accounts.values().next().value;
  return acc ? acc.qrDataUrl : null;
}

function hasExistingChat(phoneOrJid) {
  return hasAnyExistingChat(phoneOrJid);
}

module.exports = {
  initWhatsApp,
  sendTextMessage,
  checkNumberOnWhatsApp,
  hasExistingChat,
  hasAnyExistingChat,
  getQrCodeDataUrl,
  isConnected,
  getConnectedNumber,
  getAccount,
  getAllAccounts,
  createAccount,
  addNewAccount
};
