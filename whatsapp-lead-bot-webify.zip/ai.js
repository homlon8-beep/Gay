/**
 * Webify AI Sales Consultant powered by Groq (openai/gpt-oss-120b)
 * Converts business leads worldwide (focus: USA, UK, Canada, India) for:
 * 1. High-Converting Modern Websites
 * 2. 24/7 AI Lead Generation Bots (180+ leads/day)
 * STRICT RULE: NO phone calls! Everything is handled directly inside WhatsApp chat.
 */

const GROQ_API_KEY = process.env.GROQ_API_KEY;
const GROQ_MODEL = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
const AGENCY_NAME = process.env.AGENCY_NAME || 'Webify';

const SYSTEM_PROMPT = `You are Alex, an expert Digital Growth Consultant and Co-Founder at Webify (Webify Digital Solutions).

About Webify:
We help business owners, founders, contractors, and agencies worldwide scale their revenue with two core offerings:
1. Modern High-Converting Websites: Lightning-fast, mobile-first, designer-grade websites & landing pages (Next.js, Tailwind, modern stacks) engineered to turn cold visitors into booked appointments and paying customers.
2. Autonomous AI Lead Generation Bots: Cloud-hosted outreach engines that pull in 180+ qualified, verified leads every day on complete autopilot without manual prospecting.

CRITICAL ENGAGEMENT RULES:
- STRICTLY NO PHONE CALLS OR HELPLINES. Do NOT ask them to call a phone number. All consultations, quotes, questions, and demos are delivered directly right here inside this WhatsApp chat!
- Assist them right here in the conversation: "Tell me a bit about your business or what you currently do to get clients, and I can share a free live interactive preview / lead breakdown right here in chat!"
- Tone: Natural, founder-to-founder, friendly, respectful, and sharp. Never sound like an automated corporate robot or pushy spammer.
- Language:
  * Default to clean, modern, natural English (perfect for USA, UK, Canada, Australia, and global founders).
  * If the contact speaks Hindi or Hinglish, switch seamlessly to warm, natural conversational Hinglish.
- Length: Keep messages concise and readable (2 to 4 lines max). People read WhatsApp quickly.
- When they ask for Pricing:
  * Websites typically start around $299 - $799 for high-converting landing pages / business sites (or ₹15,000 - ₹35,000 in India).
  * AI Lead Bots are tailored to their target niche.
  * Tell them: "I can give you a transparent, custom breakdown right here—what niche or industry is your business in?"
- When they want a Demo / Preview:
  * "Awesome! What's your business name or website/social link? I'll put together a live interactive mockup for you today."
- If someone says STOP or is not interested:
  * "No worries at all! Wishing you and your business all the best." (and do not follow up).`;

/**
 * Call Groq API
 */
async function callGroq(messages, temperature = 0.6) {
  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GROQ_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        messages: messages,
        temperature: temperature,
        max_tokens: 500
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Groq API Error (${response.status}): ${errText}`);
    }

    const data = await response.json();
    let content = data.choices?.[0]?.message?.content?.trim() || '';
    if (!content && data.choices?.[0]?.message?.reasoning) {
      content = data.choices[0].message.reasoning.trim();
    }
    return content;
  } catch (err) {
    console.error('❌ Groq API Failure:', err.message);
    return null;
  }
}

/**
 * Natural Human Fallback Templates (Used if AI returns brackets or fails)
 * 100% realistic, casual, zero hype, zero placeholders
 */
const HUMAN_FALLBACK_TEMPLATES = [
  (trade, city) => `Hey there! Saw your ${trade} services in ${city} while checking local businesses. Just curious—do you guys have an updated website up, or are you mostly working off word of mouth right now?\n\nI can whip up a quick live preview right here in chat if you'd like to check it out, no calls needed!\n\n(Reply STOP to opt out)`,

  (trade, city) => `Hey! Hope your week is going well. Stumbled across your ${trade} work in ${city}—just wanted to ask if you're taking on more projects this month, or looking to pull in more direct client bookings?\n\nHappy to share a quick mockup right here in WhatsApp if you're open to it.\n\n(Reply STOP to opt out)`,

  (trade, city) => `Hey there! Just checking if your ${trade} business in ${city} has an updated website up or if you're looking for more steady customer inquiries this season.\n\nI can drop a quick live preview right here in chat—no call needed at all.\n\n(Reply STOP to opt out)`,

  (trade, city) => `Hey! Came across your ${trade} business around ${city}. Super quick question—do you currently have a modern booking site that brings you direct leads, or are you looking to scale up client flow?\n\nI can put together a free quick preview right here in WhatsApp for you.\n\n(Reply STOP to opt out)`
];

/**
 * Clean & Sanitize Outreach Text (Ensures NO brackets or placeholders ever leak out)
 */
function sanitizeOutreach(rawText, trade, city) {
  if (!rawText) return null;
  let text = rawText.trim();

  // If text contains bracket placeholders, replace them immediately
  text = text.replace(/\[Name\]/gi, 'there');
  text = text.replace(/\[Business\/Website\]/gi, `${trade} business`);
  text = text.replace(/\[business\]/gi, `${trade} business`);
  text = text.replace(/\[website\]/gi, 'website');
  text = text.replace(/\[trade\]/gi, trade);
  text = text.replace(/\[city\]/gi, city);
  text = text.replace(/\[.*?\]/g, ''); // Strip any remaining brackets completely

  // Remove markdown quotes or bullet stars
  text = text.replace(/^["']|["']$/g, '');
  text = text.replace(/\s+/g, ' ').trim();

  // Ensure opt-out notice is present naturally
  if (!text.toLowerCase().includes('stop')) {
    text += '\n\n(Reply STOP to opt out)';
  }

  return text;
}

const TRADE_MAP = {
  plumber: 'plumbing',
  cleaner: 'cleaning',
  roofer: 'roofing',
  painter: 'painting',
  contractor: 'contracting / remodeling',
  remodeler: 'remodeling',
  mover: 'moving',
  electrician: 'electrical',
  landscaper: 'landscaping',
  handyman: 'handyman',
  carpenter: 'carpentry'
};

/**
 * Generate humanized initial greeting message (0% Ban Risk Soft Opt-in)
 * Accepts either full lead object or parameters
 */
async function generateOutreachMessage(leadOrName = '', fallbackTrade = 'business', fallbackCity = 'your area', country = 'USA') {
  let lead = {};
  if (typeof leadOrName === 'object' && leadOrName !== null) {
    lead = leadOrName;
  } else {
    lead = { name: leadOrName, trade: fallbackTrade, city: fallbackCity, country: country };
  }

  // Parse clean trade & city
  let rawTrade = (lead.trade || lead.niche || 'local service').toLowerCase();
  const parenMatch = rawTrade.match(/^(.*?)\s*\((.*?)\)$/);
  let city = lead.city || 'your area';
  if (parenMatch) {
    rawTrade = parenMatch[1].trim();
    if (!lead.city || lead.city === 'your area') {
      city = parenMatch[2].trim();
    }
  }

  // Normalize trade through dictionary
  let trade = TRADE_MAP[rawTrade] || rawTrade;
  // Capitalize city
  city = city.charAt(0).toUpperCase() + city.slice(1);

  const isIndianLead = (lead.country === 'India' || lead.country === 'IN');

  const prompt = [
    {
      role: 'system',
      content: `You are texting someone casually on WhatsApp from your personal phone. You run Webify.
CRITICAL RULES:
- NEVER use brackets or placeholder words like [Name], [business], [city], or [anything].
- The business trade is "${trade}" and they are located in "${city}". Use these exact words naturally.
- Write like a real person sending a short, authentic WhatsApp message (2 to 3 sentences max).
- Tone: Casual, friendly, zero marketing fluff, no hype.
- Ask casually if they have an updated website up or are taking on more client bookings this month.
- Mention you can show a quick live preview right here in chat if they want, no calls needed.
- End with: (Reply STOP to opt out)`
    },
    {
      role: 'user',
      content: `Write a short, natural WhatsApp message to this ${trade} business in ${city}.`
    }
  ];

  const generated = await callGroq(prompt, 0.65);
  const cleaned = sanitizeOutreach(generated, trade, city);

  // If AI generation is clean, return it
  if (cleaned && cleaned.length > 30 && !cleaned.includes('[')) {
    return cleaned;
  }

  // Otherwise, use random human fallback template
  const templateFn = HUMAN_FALLBACK_TEMPLATES[Math.floor(Math.random() * HUMAN_FALLBACK_TEMPLATES.length)];
  return templateFn(trade, city);
}

/**
 * Handle incoming reply from a lead
 */
async function handleIncomingMessage(senderName, incomingText, history = []) {
  const messages = [
    { role: 'system', content: SYSTEM_PROMPT }
  ];

  // Append past messages if any
  if (Array.isArray(history)) {
    history.slice(-6).forEach(h => {
      messages.push({ role: h.role, content: h.content });
    });
  }

  messages.push({
    role: 'user',
    content: incomingText
  });

  const reply = await callGroq(messages, 0.6);
  if (reply) return reply;

  return `Thanks for replying! We can assist you right here in chat. What kind of business do you run, and are you more interested in getting a modern high-converting website designed, or an AI outreach bot that pulls in 180+ leads a day?`;
}

module.exports = {
  generateOutreachMessage,
  handleIncomingMessage
};
