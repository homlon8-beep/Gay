/**
 * Webify Multi-Account WhatsApp AI Lead & Outreach Engine
 * Supports multiple WhatsApp lines operating simultaneously
 * Each number harvests and messages completely different leads!
 */

require('dotenv').config();

// Global Process Crash Shield
process.on('uncaughtException', (err) => {
  console.error('🛡️ [Crash Shield - Uncaught Exception]:', err.message);
});
process.on('unhandledRejection', (reason) => {
  console.error('🛡️ [Crash Shield - Unhandled Rejection]:', reason);
});

const express = require('express');
const path = require('path');
const whatsapp = require('./whatsapp');
const scraper = require('./scraper');
const queue = require('./queue');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Anti-Sleep Keep-Alive State
let detectedBaseUrl = (process.env.RENDER_EXTERNAL_URL || process.env.PUBLIC_URL || '').replace(/\/$/, '');
let keepAliveTimer = null;
let lastPingStatus = 'Pending first ping';
let lastPingTime = 'Never';

function startKeepAliveEngine(targetUrl) {
  if (!targetUrl || keepAliveTimer) return;
  detectedBaseUrl = targetUrl.replace(/\/$/, '');
  console.log(`📡 [Anti-Sleep Keep-Alive] Engaged for: ${detectedBaseUrl}`);

  const runPing = async () => {
    try {
      const res = await fetch(`${detectedBaseUrl}/ping`, {
        headers: { 'User-Agent': 'Render-AntiSleep-Heartbeat/3.0' },
        signal: AbortSignal.timeout(10000)
      });
      lastPingStatus = `HTTP ${res.status} OK`;
      lastPingTime = new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' IST';
    } catch (err) {
      lastPingStatus = `Warn: ${err.message}`;
    }
  };

  setTimeout(runPing, 5000);
  keepAliveTimer = setInterval(runPing, 3 * 60 * 1000);
}

app.use((req, res, next) => {
  if (!detectedBaseUrl) {
    const proto = req.headers['x-forwarded-proto'] || 'https';
    const host = req.headers['x-forwarded-host'] || req.headers['host'] || req.get('host');
    if (host && !host.includes('localhost') && !host.includes('127.0.0.1')) {
      const resolved = `${proto}://${host}`;
      startKeepAliveEngine(resolved);
    }
  }
  next();
});

app.get('/healthz', (req, res) => res.status(200).send('OK'));
app.get('/ping', (req, res) => res.status(200).send('pong'));

/**
 * Multi-Account QR Scan Page (/qr)
 */
app.get('/qr', (req, res) => {
  const allAccounts = whatsapp.getAllAccounts();
  const requestedAccId = req.query.acc || (allAccounts[0]?.id || 'account_1');
  const targetAcc = whatsapp.getAccount(requestedAccId) || allAccounts[0];

  const isConnected = targetAcc ? targetAcc.isConnected : false;
  const phone = targetAcc ? targetAcc.phone : null;
  const qrDataUrl = targetAcc ? targetAcc.qrDataUrl : null;
  const label = targetAcc ? targetAcc.label : requestedAccId;

  // Render tab headers
  let tabsHtml = allAccounts.map(acc => {
    const isActive = acc.id === requestedAccId;
    const badge = acc.isConnected ? '● Connected' : (acc.qrDataUrl ? '⚡ Scan QR' : '⏳ Init');
    const badgeColor = acc.isConnected ? '#34d399' : (acc.qrDataUrl ? '#fbbf24' : '#94a3b8');
    return `
      <a href="/qr?acc=${acc.id}" class="tab-btn ${isActive ? 'active' : ''}">
        <span>${acc.label.split('(')[0].trim()}</span>
        <span class="tab-badge" style="color: ${badgeColor};">${badge}</span>
      </a>
    `;
  }).join('');

  tabsHtml += `
    <form method="POST" action="/api/accounts/add" style="display: inline;">
      <button type="submit" class="tab-btn add-btn" title="Add another WhatsApp number">+ Add Line</button>
    </form>
  `;

  let cardBody = '';
  if (isConnected) {
    cardBody = `
      <div class="card connected">
        <div class="icon">✅</div>
        <h2>${label} Connected!</h2>
        <p class="phone">+${phone}</p>
        <p class="desc">This WhatsApp number is linked and actively harvesting &amp; sending verified leads on its dedicated territory.</p>
        <div style="display: flex; gap: 0.75rem; justify-content: center; margin-top: 1.5rem;">
          <a href="/" class="btn">Dashboard</a>
          <a href="/qr?acc=${requestedAccId}&reconnect=1" class="btn btn-outline" style="border-color: #475569; color: #cbd5e1;">Switch Number</a>
        </div>
      </div>
    `;
  } else if (qrDataUrl) {
    cardBody = `
      <div class="card">
        <h2>Link ${label}</h2>
        <p class="subtitle">Open WhatsApp > Linked Devices > Link a Device</p>
        <div class="qr-box">
          <img src="${qrDataUrl}" alt="WhatsApp QR Code" class="qr-img" />
        </div>
        <p class="refresh-hint">QR Code refreshes automatically every 5 seconds.</p>
      </div>
    `;
  } else {
    cardBody = `
      <div class="card">
        <div class="spinner"></div>
        <h2>Initializing ${label}...</h2>
        <p class="desc">Generating a new QR code for this line, please wait a few seconds...</p>
      </div>
    `;
  }

  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="refresh" content="5">
      <title>WhatsApp Multi-Line QR Link - Webify</title>
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { background: #090d16; color: #fff; min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 1.5rem; }
        .tabs-nav { display: flex; gap: 0.5rem; margin-bottom: 1.5rem; flex-wrap: wrap; justify-content: center; max-width: 500px; }
        .tab-btn { background: #131c2e; border: 1px solid #1e293b; color: #94a3b8; padding: 0.65rem 1rem; border-radius: 12px; text-decoration: none; font-size: 0.85rem; font-weight: 700; display: inline-flex; align-items: center; gap: 0.5rem; transition: all 0.2s; }
        .tab-btn:hover { background: #1e293b; color: #f8fafc; }
        .tab-btn.active { background: #0284c7; border-color: #38bdf8; color: #fff; box-shadow: 0 4px 14px rgba(2, 132, 199, 0.4); }
        .tab-btn.add-btn { background: #064e3b; border-color: #059669; color: #6ee7b7; cursor: pointer; }
        .tab-badge { font-size: 0.72rem; padding: 0.15rem 0.4rem; border-radius: 9999px; background: rgba(0,0,0,0.3); }
        .card { background: #131c2e; border: 1px solid #1e293b; border-radius: 20px; padding: 2.25rem 2rem; max-width: 440px; width: 100%; text-align: center; box-shadow: 0 20px 40px rgba(0,0,0,0.5); }
        .card.connected { border-color: #059669; }
        h2 { font-size: 1.4rem; margin-bottom: 0.5rem; color: #f8fafc; }
        .subtitle { color: #94a3b8; font-size: 0.88rem; margin-bottom: 1.25rem; }
        .qr-box { background: #fff; padding: 0.85rem; border-radius: 16px; display: inline-block; margin-bottom: 1.25rem; }
        .qr-img { width: 250px; height: 250px; display: block; }
        .phone { font-size: 1.3rem; font-weight: 800; color: #34d399; margin: 0.5rem 0 1rem; }
        .desc { color: #94a3b8; font-size: 0.9rem; line-height: 1.5; margin-bottom: 1rem; }
        .btn { display: inline-block; background: #0284c7; color: #fff; text-decoration: none; padding: 0.7rem 1.4rem; border-radius: 10px; font-weight: 700; font-size: 0.9rem; }
        .btn:hover { background: #0369a1; }
        .btn-outline { background: transparent; border: 1px solid #334155; }
        .icon { font-size: 2.8rem; margin-bottom: 0.75rem; }
        .refresh-hint { font-size: 0.78rem; color: #64748b; }
        .spinner { width: 40px; height: 40px; border: 4px solid #1e293b; border-top-color: #38bdf8; border-radius: 50%; animation: spin 1s infinite linear; margin: 0 auto 1.25rem; }
        @keyframes spin { 100% { transform: rotate(360deg); } }
      </style>
    </head>
    <body>
      <div class="tabs-nav">
        ${tabsHtml}
      </div>
      ${cardBody}
    </body>
    </html>
  `);
});

/**
 * Main Web Dashboard (/)
 */
app.get('/', (req, res) => {
  const allAccounts = whatsapp.getAllAccounts();
  const queueState = queue.getQueueState();
  const scraperStats = scraper.getScraperStats();
  const totalShielded = scraper.getTotalShieldedCount ? scraper.getTotalShieldedCount() : 0;

  const connectedCount = allAccounts.filter(a => a.isConnected).length;
  const maxDailyCapacity = allAccounts.length * 150;

  // Build Accounts Cards HTML
  const accountsCardsHtml = allAccounts.map(acc => {
    const state = queueState.accounts.find(s => s.accountId === acc.id) || {
      currentBatchCount: 0,
      dailySentCount: 0,
      currentStatus: 'Standby',
      nextActionTime: 'None',
      isPaused: false
    };

    const territory = scraper.getTerritoryForAccount(acc.id);
    const queuedForAcc = scraper.getQueuedLeadsCount(acc.id);

    return `
      <div class="acc-card ${acc.isConnected ? 'connected' : 'waiting'}">
        <div class="acc-card-header">
          <div>
            <div class="acc-title">${acc.label}</div>
            <div class="acc-phone">${acc.isConnected ? `📞 +${acc.phone}` : '⚠️ Not Linked'}</div>
          </div>
          <div>
            <span class="acc-badge ${acc.isConnected ? 'badge-live' : 'badge-wait'}">
              ${acc.isConnected ? '● ACTIVE' : 'WAITING QR'}
            </span>
          </div>
        </div>

        <div class="acc-territory">
          <strong>Territory:</strong> ${territory.name} (${territory.cities.slice(0, 3).map(c => c.toUpperCase()).join(', ')}...)
        </div>

        <div class="acc-stats-row">
          <div class="mini-stat">
            <div class="mini-val" style="color: #38bdf8;">${state.currentBatchCount} / 15</div>
            <div class="mini-label">Batch (15)</div>
          </div>
          <div class="mini-stat">
            <div class="mini-val" style="color: #34d399;">${state.dailySentCount} / 150</div>
            <div class="mini-label">Today's Cap</div>
          </div>
          <div class="mini-stat">
            <div class="mini-val" style="color: #fbbf24;">${queuedForAcc}</div>
            <div class="mini-label">Queued Leads</div>
          </div>
        </div>

        <div class="acc-status-box">
          Status: <strong>${state.currentStatus}</strong><br>
          Next Pacing Delay: <strong>${state.nextActionTime || 'Ready'}</strong>
        </div>

        <div class="acc-actions">
          ${acc.isConnected ? `
            <a href="/qr?acc=${acc.id}" class="acc-btn acc-btn-blue">Line Details</a>
            ${state.isPaused ? `
              <form method="POST" action="/api/queue/resume" style="margin: 0; display: inline;">
                <input type="hidden" name="acc" value="${acc.id}">
                <button type="submit" class="acc-btn acc-btn-green">▶️ Resume</button>
              </form>
            ` : `
              <form method="POST" action="/api/queue/pause" style="margin: 0; display: inline;">
                <input type="hidden" name="acc" value="${acc.id}">
                <button type="submit" class="acc-btn acc-btn-red">🛑 Pause</button>
              </form>
            `}
          ` : `
            <a href="/qr?acc=${acc.id}" class="acc-btn acc-btn-yellow" style="width: 100%; text-align: center;">📲 Scan QR to Link</a>
          `}
        </div>
      </div>
    `;
  }).join('');

  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="refresh" content="8">
      <title>Webify Multi-Number AI Lead Bot Dashboard</title>
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { background: #090d16; color: #f1f5f9; padding: 1.5rem; }
        .container { max-width: 900px; margin: 0 auto; }
        header { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #1e293b; padding-bottom: 1.25rem; margin-bottom: 1.75rem; flex-wrap: wrap; gap: 1rem; }
        h1 { font-size: 1.5rem; color: #38bdf8; }
        .status-badge { display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.45rem 1rem; border-radius: 9999px; font-size: 0.85rem; font-weight: 700; }
        .status-badge.online { background: #064e3b; color: #6ee7b7; border: 1px solid #059669; }
        .status-badge.warning { background: #78350f; color: #fde68a; border: 1px solid #d97706; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 1.75rem; }
        .stat-card { background: #131c2e; border: 1px solid #1e293b; border-radius: 14px; padding: 1.25rem; text-align: center; }
        .stat-val { font-size: 1.75rem; font-weight: 800; color: #38bdf8; margin-top: 0.35rem; }
        .stat-label { font-size: 0.78rem; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.05em; }
        .section-box { background: #131c2e; border: 1px solid #1e293b; border-radius: 14px; padding: 1.5rem; margin-bottom: 1.5rem; }
        h3 { font-size: 1.15rem; margin-bottom: 1rem; color: #f8fafc; }
        
        /* Multi-Account Cards */
        .acc-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1.25rem; margin-bottom: 1.5rem; }
        .acc-card { background: #0e1626; border: 1px solid #1e293b; border-radius: 16px; padding: 1.4rem; transition: transform 0.2s; position: relative; }
        .acc-card.connected { border-color: #059669; }
        .acc-card.waiting { border-color: #d97706; }
        .acc-card-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.75rem; }
        .acc-title { font-size: 1.05rem; font-weight: 800; color: #f8fafc; }
        .acc-phone { font-size: 0.88rem; color: #34d399; font-weight: 700; margin-top: 0.2rem; font-family: monospace; }
        .acc-badge { font-size: 0.72rem; padding: 0.2rem 0.6rem; border-radius: 9999px; font-weight: 800; }
        .badge-live { background: #064e3b; color: #6ee7b7; border: 1px solid #059669; }
        .badge-wait { background: #78350f; color: #fde68a; border: 1px solid #d97706; }
        .acc-territory { font-size: 0.8rem; color: #94a3b8; margin-bottom: 1rem; line-height: 1.4; background: #090d16; padding: 0.5rem 0.75rem; border-radius: 8px; }
        .acc-stats-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.5rem; text-align: center; margin-bottom: 1rem; }
        .mini-stat { background: #131c2e; padding: 0.65rem 0.4rem; border-radius: 10px; border: 1px solid #1e293b; }
        .mini-val { font-size: 1.15rem; font-weight: 800; }
        .mini-label { font-size: 0.68rem; color: #94a3b8; text-transform: uppercase; margin-top: 0.15rem; }
        .acc-status-box { background: #090d16; padding: 0.75rem; border-radius: 8px; font-family: monospace; font-size: 0.8rem; color: #cbd5e1; margin-bottom: 1rem; min-height: 50px; }
        .acc-actions { display: flex; gap: 0.5rem; }
        .acc-btn { padding: 0.5rem 1rem; border-radius: 8px; font-weight: 700; font-size: 0.82rem; text-decoration: none; border: none; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; }
        .acc-btn-blue { background: #0284c7; color: #fff; flex: 1; }
        .acc-btn-green { background: #16a34a; color: #fff; }
        .acc-btn-red { background: #dc2626; color: #fff; }
        .acc-btn-yellow { background: #d97706; color: #fff; }

        .btn { padding: 0.65rem 1.25rem; border-radius: 8px; font-weight: 700; text-decoration: none; border: none; cursor: pointer; font-size: 0.88rem; display: inline-flex; align-items: center; gap: 0.4rem; }
        .btn-green { background: #0284c7; color: #fff; }
        .btn-outline { background: transparent; border: 1px solid #334155; color: #cbd5e1; }
        textarea { width: 100%; height: 85px; background: #090d16; border: 1px solid #334155; border-radius: 8px; color: #fff; padding: 0.75rem; font-size: 0.88rem; margin-bottom: 0.75rem; resize: vertical; }
        .log-box { background: #090d16; padding: 0.85rem; border-radius: 8px; font-family: monospace; font-size: 0.82rem; color: #94a3b8; }
      </style>
    </head>
    <body>
      <div class="container">
        <header>
          <div>
            <h1>Webify Multi-Number AI Lead Bot</h1>
            <p style="color: #64748b; font-size: 0.85rem; margin-top: 0.2rem;">Multi-Line WhatsApp Engine • Partitioned Territories • Different Leads All Time • Anti-Ban 150/Day Pacing</p>
          </div>
          <div style="display: flex; gap: 0.65rem; align-items: center;">
            <span class="status-badge ${connectedCount > 0 ? 'online' : 'warning'}">
              ${connectedCount > 0 ? `● ${connectedCount} Lines Online` : '⚠️ No Lines Connected'}
            </span>
            <a href="/qr" class="btn btn-green" style="padding: 0.45rem 0.9rem; font-size: 0.82rem;">📲 Link Numbers</a>
          </div>
        </header>

        <!-- Top Global Metrics Grid -->
        <div class="grid">
          <div class="stat-card">
            <div class="stat-label">Active WhatsApp Lines</div>
            <div class="stat-val" style="color: #38bdf8;">${connectedCount} / ${allAccounts.length}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Total Delivered Today</div>
            <div class="stat-val" style="color: #34d399;">${queueState.totalDailySent} / ${maxDailyCapacity}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Total Delivered (All Time)</div>
            <div class="stat-val">${queueState.totalSentDb}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Total Queued Leads</div>
            <div class="stat-val" style="color: #fbbf24;">${queueState.queuedRemaining}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Shielded Past Numbers</div>
            <div class="stat-val" style="color: #a855f7;">${totalShielded}</div>
          </div>
        </div>

        <!-- Multi-Account WhatsApp Control Hub -->
        <div class="section-box" style="border-left: 4px solid #38bdf8;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem; flex-wrap: wrap; gap: 0.75rem;">
            <div>
              <h3 style="margin: 0; color: #38bdf8;">📱 Multi-Number WhatsApp Dispatch Hub</h3>
              <p style="color: #94a3b8; font-size: 0.85rem; margin-top: 0.2rem;">Each number operates on its own territory, pulling different leads with separate anti-ban timers.</p>
            </div>
            <form method="POST" action="/api/accounts/add" style="margin: 0;">
              <button type="submit" class="btn btn-green" style="background: #059669;">➕ Add Another Line</button>
            </form>
          </div>

          <div class="acc-grid">
            ${accountsCardsHtml}
          </div>
        </div>

        <!-- Add Custom Numbers to Queue -->
        <div class="section-box">
          <h3>📥 Add Global Phone Numbers to Queue</h3>
          <form method="POST" action="/api/leads/add-form">
            <textarea name="numbers" placeholder="Paste numbers with country code (e.g. +1 (415) 555-2671, +44 7911 123456, or 10-digit US numbers)..."></textarea>
            <div style="display: flex; gap: 0.75rem; align-items: center; flex-wrap: wrap;">
              <select name="assignedAccount" style="background: #090d16; border: 1px solid #334155; color: #fff; padding: 0.65rem 1rem; border-radius: 8px; font-size: 0.85rem;">
                <option value="">Auto-Assign by Available Queue</option>
                ${allAccounts.map(a => `<option value="${a.id}">Assign specifically to ${a.label}</option>`).join('')}
              </select>
              <button type="submit" class="btn btn-green">+ Add to Lead Queue</button>
            </div>
          </form>
        </div>

        <!-- Older Bot Shield -->
        <div class="section-box" style="border-left: 4px solid #a855f7;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <h3 style="margin: 0; color: #c084fc;">🛡️ Multi-Line Duplicate Shield (Older Bot Contacts)</h3>
            <span style="background: #581c87; color: #e9d5ff; font-size: 0.75rem; padding: 0.2rem 0.6rem; border-radius: 9999px; font-weight: 700;">GLOBAL SHIELD</span>
          </div>
          <p style="color: #94a3b8; font-size: 0.85rem; margin-bottom: 0.75rem;">
            Numbers shielded here are globally blocked across <strong>all your WhatsApp lines</strong> so no number ever contacts them.
          </p>
          <form method="POST" action="/api/leads/shield-past">
            <textarea name="pastNumbers" placeholder="Paste older bot numbers here (one per line, e.g. 14695545603 or 214-789-5884)..."></textarea>
            <button type="submit" class="btn" style="background: #7c3aed; color: #fff; font-weight: 700; cursor: pointer;">🛡️ Permanently Shield Across All Lines</button>
          </form>
        </div>

        <!-- 24/7 Autonomous Scraper Engine -->
        <div class="section-box" style="border-color: #059669; background: #064e3b12;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <h3 style="margin: 0; color: #34d399;">🌐 24/7 Continuous Multi-Territory Harvester</h3>
            <span style="background: ${scraperStats.isPaused ? '#7f1d1d' : '#064e3b'}; color: ${scraperStats.isPaused ? '#fca5a5' : '#a7f3d0'}; font-size: 0.75rem; padding: 0.2rem 0.6rem; border-radius: 9999px; font-weight: 700;">${scraperStats.isPaused ? 'PAUSED' : 'ACTIVE 24/7'}</span>
          </div>
          <p style="color: #94a3b8; font-size: 0.88rem; margin-bottom: 0.75rem;">
            Dynamically harvests diverse leads for each line across 40+ US &amp; Global cities with query rotation so your bot delivers different leads all the time.
          </p>
          <p class="log-box" style="margin-bottom: 0.75rem;">
            Status: <strong>${scraperStats.status}</strong><br>
            Completed Sweeps: <strong>${scraperStats.cyclesCompleted}</strong> | Discovered This Session: <strong>${scraperStats.leadsHarvestedSession}</strong> | Database Total: <strong>${scraperStats.totalInDb}</strong>
          </p>
          <div style="display: flex; gap: 0.75rem; flex-wrap: wrap;">
            <form method="POST" action="/api/scraper/trigger-free-form" style="margin: 0;">
              <button type="submit" class="btn btn-green">⚡ Run Extra Instant Sweep</button>
            </form>
            ${scraperStats.isPaused ? `
              <form method="POST" action="/api/scraper/resume" style="margin: 0;">
                <button type="submit" class="btn" style="background: #16a34a; color: #fff; cursor: pointer;">▶️ Resume Scraper</button>
              </form>
            ` : `
              <form method="POST" action="/api/scraper/pause" style="margin: 0;">
                <button type="submit" class="btn" style="background: #dc2626; color: #fff; cursor: pointer;">🛑 Stop Scraper</button>
              </form>
            `}
          </div>
        </div>

        <!-- Render Anti-Sleep Keep-Alive Shield -->
        <div class="section-box" style="border-left: 4px solid #38bdf8;">
          <h3 style="margin: 0; color: #38bdf8; margin-bottom: 0.5rem;">🛡️ Render Anti-Sleep Heartbeat (24/7 Online)</h3>
          <p style="color: #94a3b8; font-size: 0.85rem; margin-bottom: 0.5rem;">
            Status: <strong style="color: #34d399;">${lastPingStatus}</strong> (Last Ping: ${lastPingTime}) | Interval: <strong>Every 3 minutes</strong>
          </p>
          <p style="font-size: 0.8rem; color: #64748b;">
            Keeps your Render web service awake around the clock so multiple WhatsApp lines keep sending on their exact schedules.
          </p>
        </div>
      </div>
    </body>
    </html>
  `);
});

/**
 * API Endpoints
 */
app.post('/api/accounts/add', async (req, res) => {
  try {
    await whatsapp.addNewAccount();
    res.redirect('/qr');
  } catch (err) {
    res.redirect('/?error=' + encodeURIComponent(err.message));
  }
});

app.post('/api/leads/add-form', (req, res) => {
  const numbersText = req.body.numbers || '';
  const assignedAccount = req.body.assignedAccount || null;
  const lines = numbersText.split('\n');
  const leads = [];

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed) {
      leads.push({
        phone: trimmed,
        assignedAccount: assignedAccount,
        source: 'manual_dashboard'
      });
    }
  }

  const result = scraper.addLeadsToQueue(leads, assignedAccount);
  res.redirect(`/?added=${result.added}`);
});

app.post('/api/leads/shield-past', (req, res) => {
  const numbersText = req.body.pastNumbers || '';
  const lines = numbersText.split('\n');
  const numbersToShield = [];

  for (const line of lines) {
    const cleanDigits = line.replace(/\D/g, '');
    if (cleanDigits && cleanDigits.length >= 7) {
      numbersToShield.push(cleanDigits);
    }
  }

  const result = scraper.recordBulkSentPhones(numbersToShield);

  try {
    const db = scraper.loadDatabase();
    for (const lead of db.leads) {
      if (scraper.isPhoneAlreadySent(lead.phone)) {
        lead.status = 'sent';
      }
    }
    scraper.saveDatabase(db);
  } catch (e) {}

  res.redirect(`/?shielded=true&count=${result.added}`);
});

app.post('/api/queue/pause', (req, res) => {
  const acc = req.body.acc || null;
  queue.pauseQueue(acc);
  res.redirect('/?paused=true');
});

app.post('/api/queue/resume', (req, res) => {
  const acc = req.body.acc || null;
  queue.resumeQueue(acc);
  res.redirect('/?resumed=true');
});

app.post('/api/scraper/pause', (req, res) => {
  scraper.pauseScraper();
  res.redirect('/?scraper_paused=true');
});

app.post('/api/scraper/resume', (req, res) => {
  scraper.resumeScraper();
  res.redirect('/?scraper_resumed=true');
});

app.post('/api/scraper/trigger-free-form', async (req, res) => {
  try {
    await scraper.triggerFreeWebScraper({ targetCount: 30 });
  } catch (err) {}
  res.redirect('/?scraper=free_triggered');
});

/**
 * Start Server & Multi-Account WhatsApp Clients
 */
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n==============================================`);
  console.log(`🚀 Webify Multi-Number WhatsApp Bot running on Port ${PORT}`);
  console.log(`📲 Open http://localhost:${PORT}/qr to link WhatsApp numbers`);
  console.log(`==============================================\n`);

  // Start continuous multi-territory scraper
  scraper.start247ContinuousScraper().catch(e => console.error("24/7 Scraper Boot Error:", e.message));

  // Initialize WhatsApp accounts and start master queue dispatcher
  let queueStarted = false;
  whatsapp.initWhatsApp(() => {
    if (!queueStarted) {
      queueStarted = true;
      console.log('🤖 [Multi-Queue Engine] WhatsApp line active! Starting Queue Dispatcher...');
      queue.startQueueWorker(whatsapp);
    }
  });
});
