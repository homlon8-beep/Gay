/**
 * Webify Multi-Account Anti-Ban Queue Dispatcher
 * Runs independent, rate-limited worker loops for each connected WhatsApp number.
 * Each number delivers up to 150 real verified leads per 24 hours on its own territory
 * with 1 msg every ~110s (Batch of 15) -> 115-minute cool-down break.
 * 2 Numbers = 300 real leads/day | 3 Numbers = 450 real leads/day!
 */

const ai = require('./ai');
const scraper = require('./scraper');

const BATCH_SIZE = parseInt(process.env.BATCH_SIZE || '15', 10);
const DELAY_BETWEEN_MSGS_MS = parseInt(process.env.DELAY_BETWEEN_MSGS_MS || '110000', 10); // ~110s
const BATCH_BREAK_MS = parseInt(process.env.BATCH_BREAK_MS || '6900000', 10); // 115 minutes
const DAILY_MAX_LEADS = parseInt(process.env.DAILY_MAX_LEADS || '150', 10); // 150 real leads per number

// Per-Account Worker States: accountId -> State
const accountStates = new Map();
let currentCalendarDay = new Date().toDateString();

function getOrCreateAccountState(accountId) {
  if (accountStates.has(accountId)) return accountStates.get(accountId);

  const state = {
    accountId,
    isRunning: false,
    isPaused: false,
    currentBatchCount: 0,
    dailySentCount: 0,
    totalSentSession: 0,
    currentStatus: 'Initializing Line...',
    nextActionTime: null,
    currentLead: null
  };

  accountStates.set(accountId, state);
  return state;
}

function checkAndResetDailyCounters() {
  const today = new Date().toDateString();
  if (today !== currentCalendarDay) {
    currentCalendarDay = today;
    for (const state of accountStates.values()) {
      state.dailySentCount = 0;
      console.log(`🌅 [Anti-Ban Engine - ${state.accountId}] New calendar day. Daily counter reset to 0/${DAILY_MAX_LEADS}`);
    }
  }
}

function formatIndiaTime(timestamp) {
  if (!timestamp) return null;
  try {
    return new Date(timestamp).toLocaleTimeString('en-IN', {
      timeZone: 'Asia/Kolkata',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }) + ' IST';
  } catch (e) {
    return new Date(timestamp).toLocaleTimeString('en-IN') + ' IST';
  }
}

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Worker Loop for a single WhatsApp Account
 */
async function runWorkerForAccount(accountId, whatsappClient) {
  const state = getOrCreateAccountState(accountId);
  if (state.isRunning) return;
  state.isRunning = true;

  console.log(`🚀 [Worker - ${accountId}] Started dedicated dispatcher! Target: 150 unique leads/day on separate territory.`);

  while (state.isRunning) {
    if (state.isPaused) {
      state.currentStatus = 'Paused by User';
      await sleep(4000);
      continue;
    }

    checkAndResetDailyCounters();

    // Check if this account's daily limit is reached
    if (state.dailySentCount >= DAILY_MAX_LEADS) {
      state.currentStatus = `Daily 150 Cap Reached (${state.dailySentCount}/${DAILY_MAX_LEADS}). Resting until midnight...`;
      await sleep(60000);
      continue;
    }

    const account = whatsappClient.getAccount(accountId);
    if (!account || !account.isConnected) {
      state.currentStatus = 'Waiting for QR Code link...';
      await sleep(8000);
      continue;
    }

    // Top up queue for this account's territory if low (< 25 leads)
    const remainingForAcc = scraper.getQueuedLeadsCount(accountId);
    if (remainingForAcc < 25) {
      state.currentStatus = `Queue has ${remainingForAcc} leads. Harvesting fresh leads for ${accountId}...`;
      scraper.triggerFreeWebScraper({ targetAccount: accountId, targetCount: 30 })
        .catch(e => console.warn(`Scraper note for ${accountId}:`, e.message));
    }

    // Pull next lead assigned to or available for this account
    let lead = scraper.getQueuedLeadForAccount(accountId);
    if (!lead) {
      state.currentStatus = 'Queue Empty: Harvesting fresh leads for this line...';
      try {
        await scraper.triggerFreeWebScraper({ targetAccount: accountId, targetCount: 30 });
      } catch (e) {}
      lead = scraper.getQueuedLeadForAccount(accountId);
      if (!lead) {
        await sleep(15000);
        continue;
      }
    }

    state.currentLead = lead.phone;

    // Absolute duplicate protection across all accounts & past sessions
    if (scraper.isPhoneAlreadySent(lead.phone) || whatsappClient.hasAnyExistingChat(lead.phone) || lead.status === 'sent') {
      console.log(`⏩ [Duplicate Shield - ${accountId}] ${lead.phone} was already contacted by another line or past bot. Skipping!`);
      scraper.updateLeadStatus(lead.phone, 'sent');
      continue;
    }

    // 2. CHECK IF NUMBER IS REGISTERED ON WHATSAPP
    state.currentStatus = `Checking WhatsApp status for ${lead.phone}...`;
    const waCheck = await whatsappClient.checkNumberOnWhatsApp(accountId, lead.phone);
    if (!waCheck.exists) {
      console.log(`❌ [Not on WhatsApp - ${accountId}] ${lead.phone} is not on WhatsApp. Instant skip (150ms)!`);
      scraper.updateLeadStatus(lead.phone, 'not_on_whatsapp');
      await sleep(150);
      continue;
    }

    lead.jid = waCheck.jid;

    // Check batch limit (15 messages) -> Take 115-min cool-down break
    if (state.currentBatchCount >= BATCH_SIZE) {
      state.currentStatus = `Batch of ${BATCH_SIZE} complete. Taking 115-min cool-down break...`;
      state.nextActionTime = Date.now() + BATCH_BREAK_MS;
      console.log(`\n☕ [Worker - ${accountId}] Exactly ${BATCH_SIZE} verified messages delivered on +${account.phone}! Taking 115-min break until ${formatIndiaTime(state.nextActionTime)}...\n`);
      await sleep(BATCH_BREAK_MS);
      state.currentBatchCount = 0;
      console.log(`⚡ [Worker - ${accountId}] Cool-down break finished! Resuming next batch...`);
    }

    // Generate personalized message via Groq AI
    state.currentStatus = `Generating AI outreach for ${lead.phone} (${lead.city || 'USA'})...`;
    const outreachText = await ai.generateOutreachMessage(lead);

    // Send via this account's WhatsApp line
    state.currentStatus = `Sending message to ${lead.phone} via +${account.phone}...`;
    let sendSucceeded = false;

    try {
      const sent = await whatsappClient.sendTextMessage(accountId, lead.jid, outreachText);
      if (sent) {
        scraper.updateLeadStatus(lead.phone, 'sent');
        state.currentBatchCount++;
        state.totalSentSession++;
        state.dailySentCount++;
        sendSucceeded = true;
        console.log(`✅ [Real Sent on Line ${accountId}] (${state.currentBatchCount}/${BATCH_SIZE}) to ${lead.phone}. Line Today: ${state.dailySentCount}/${DAILY_MAX_LEADS}`);
      } else {
        scraper.updateLeadStatus(lead.phone, 'failed', 'Socket send failure');
      }
    } catch (err) {
      console.error(`❌ [Send Error on ${accountId}]:`, err.message);
      scraper.updateLeadStatus(lead.phone, 'failed', err.message);
    }

    // Apply human pacing if delivered
    if (sendSucceeded) {
      if (state.currentBatchCount >= BATCH_SIZE) {
        state.currentStatus = `Batch of ${BATCH_SIZE} complete. Taking 115-min cool-down break...`;
        state.nextActionTime = Date.now() + BATCH_BREAK_MS;
        console.log(`\n☕ [Worker - ${accountId}] Batch complete (${BATCH_SIZE} delivered). Taking 115-min break until ${formatIndiaTime(state.nextActionTime)}...\n`);
        await sleep(BATCH_BREAK_MS);
        state.currentBatchCount = 0;
      } else {
        // Dynamic Human Jitter: 95s to 125s (averaging ~110 seconds)
        const jitter = Math.floor(95000 + Math.random() * 30000);
        state.currentStatus = `Waiting ${Math.round(jitter / 1000)}s before next lead (~110s pacing)...`;
        state.nextActionTime = Date.now() + jitter;
        console.log(`⏳ [Pacing ~110s - ${accountId}] Next message at ${formatIndiaTime(state.nextActionTime)} (${Math.round(jitter / 1000)}s delay)...`);
        await sleep(jitter);
      }
    } else {
      await sleep(1000);
    }
  }
}

/**
 * Start the master queue dispatcher across all accounts
 */
async function startQueueWorker(whatsappClient) {
  console.log(`🚀 [Master Multi-Queue] Active! Managing independent 24-Hour lines for each WhatsApp number...`);

  // Start background continuous scraper
  scraper.start247ContinuousScraper().catch(e => console.error('Continuous scraper error:', e.message));

  // Launch worker loops for registered accounts
  const allAccounts = whatsappClient.getAllAccounts();
  for (const acc of allAccounts) {
    runWorkerForAccount(acc.id, whatsappClient).catch(e => console.error(`Worker error for ${acc.id}:`, e.message));
  }

  // Periodic watcher to launch workers for any newly added account
  setInterval(() => {
    const freshAccounts = whatsappClient.getAllAccounts();
    for (const acc of freshAccounts) {
      const state = getOrCreateAccountState(acc.id);
      if (!state.isRunning) {
        runWorkerForAccount(acc.id, whatsappClient).catch(e => console.error(`Worker error for ${acc.id}:`, e.message));
      }
    }
  }, 10000);
}

function pauseQueue(accountId = null) {
  if (accountId && accountStates.has(accountId)) {
    accountStates.get(accountId).isPaused = true;
    console.log(`⏸️ [Queue Worker] Paused line: ${accountId}`);
  } else {
    for (const s of accountStates.values()) s.isPaused = true;
    console.log('⏸️ [Queue Worker] Paused all lines');
  }
}

function resumeQueue(accountId = null) {
  if (accountId && accountStates.has(accountId)) {
    accountStates.get(accountId).isPaused = false;
    console.log(`▶️ [Queue Worker] Resumed line: ${accountId}`);
  } else {
    for (const s of accountStates.values()) s.isPaused = false;
    console.log('▶️ [Queue Worker] Resumed all lines');
  }
}

function getQueueState() {
  const db = scraper.loadDatabase();
  const queuedCount = db.leads.filter(l => l.status === 'queued').length;
  const sentCount = db.leads.filter(l => l.status === 'sent').length;
  checkAndResetDailyCounters();

  let totalDailySentAllAccounts = 0;
  const accountBreakdown = [];

  for (const [id, s] of accountStates.entries()) {
    totalDailySentAllAccounts += s.dailySentCount;
    accountBreakdown.push({
      accountId: id,
      isRunning: s.isRunning,
      isPaused: s.isPaused,
      currentStatus: s.currentStatus,
      currentBatchCount: s.currentBatchCount,
      batchSize: BATCH_SIZE,
      dailySentCount: s.dailySentCount,
      dailyMaxLeads: DAILY_MAX_LEADS,
      totalSentSession: s.totalSentSession,
      currentLead: s.currentLead,
      nextActionTime: formatIndiaTime(s.nextActionTime)
    });
  }

  return {
    accounts: accountBreakdown,
    totalAccounts: accountStates.size,
    totalDailySent: totalDailySentAllAccounts,
    totalSentDb: sentCount,
    queuedRemaining: queuedCount,
    batchSize: BATCH_SIZE,
    dailyMaxPerAccount: DAILY_MAX_LEADS
  };
}

module.exports = {
  startQueueWorker,
  pauseQueue,
  resumeQueue,
  getQueueState
};
